import axios from 'axios'

const Patient_API_BASE_URL = 'http://localhost:8080/patient'
const Get_All_Patient = 'http://localhost:8080/patient'



class PatientServices {
     async getPatients() {
        return axios.get(Get_All_Patient);
    }
    async getPatient(Id) {
        return axios.get(Patient_API_BASE_URL+Id);
    }
    async deletePatient(patientId) {
        const response = await axios.delete(Patient_API_BASE_URL+patientId)
        return response.data;
    }
    async createPatient(requestData) {
        const response = await axios.post(Patient_API_BASE_URL + requestData)
        return response.data;
    }
    async updatePatient(patientId,requestData,) {
        const response = await axios.put(Patient_API_BASE_URL +patientId, requestData)
        return response.data;
    }



}



export default new PatientServices()



