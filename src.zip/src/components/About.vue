<template>

    <v-app id="inspire">
        <v-app-bar app color="white" flat>
            <v-container class="py-0 fill-height">

                <!-- Menu Buttons -->
                <v-btn to="/" text>Dashboard</v-btn>
                <v-btn to="/login" text>Login</v-btn>
                <v-btn to="/register" text>Register</v-btn>
                <v-btn to="/about" text>About</v-btn>
                <v-spacer></v-spacer>
                <v-responsive max-width="260"> </v-responsive>
            </v-container>
        </v-app-bar>
        <!-- Main content -->
        <v-main class="grey lighten-3">
            <v-container>
                <v-row>
                    <v-col>
                        <v-sheet min-height="70vh" rounded="lg">

                            <div id="background" style="padding-top:20px;">




                                <center>
                                    <div id="divLogin" class="col-sm-3 my-sm-5 border rounded" style="margin-left:0.5%">



                                        <template>
                                            <CENTER>
                                                <div>
                                                    <br />
                                                    <br />
                                                    <br />

                                                    <v-text-field label="Main input"
                                                                  :rules="rules"
                                                                  hide-details="auto"></v-text-field>
                                                    <v-text-field label="Another input"></v-text-field>
                                                </div>
                                            </CENTER>
                                        </template>
                                        </div>
                                    </center>
                                </div>

                                        <router-view>

                                        </router-view>
                        </v-sheet>
                    </v-col>
                </v-row>
            </v-container>
        </v-main>
    </v-app>





</template>










<script>

    export default {
        name: "About",
        data() {
            return {
            };
        },
        methods: {
        },
        mounted() {
        },
    }
</script>
