<template>
    <div id="app">
        <Home />

       <Nav />
        <div class="pa-container">
            
        </div>
    </div>
</template>

<script>
    
</script>

<style>
    p {
        margin-left: 30px;
        padding-block: 30px;
        border: hidden;
        text-decoration: dotted;
        text-size-adjust: auto;
        text-shadow: 2px;
        text-wrap: 30px;
        text-emphasis-color: saddlebrown;
        backdrop-filter: blur();
    }

    a {
        text-decoration: none;
        text-emphasis-color: cadetblue;
    }
</style>
